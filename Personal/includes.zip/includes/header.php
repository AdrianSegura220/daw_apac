	<header class="cd-header">
		<a href="#0" class="cd-logo"><img src="img/cd-logo.svg" alt="Logo"></a>
		<a href="#0" class="cd-3d-nav-trigger">
			Menu
			<span></span>
		</a>
	</header> <!-- .cd-header -->
