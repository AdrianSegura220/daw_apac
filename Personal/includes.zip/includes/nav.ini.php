
  <nav>
    <div class="nav-wrapper color1">
      <a href="home.html" class="brand-logo">LogoAPAC </a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="index.php">Inicio</a></li>
        <li><a href="">APAC</a></li>
        <li><a href="">Torneos</a></li>
        <li><a class="modal-trigger" data-target="modal_iniciarSesion">Iniciar Sesion/Registrarse</a></li>
      </ul>
    </div>
  </nav>
