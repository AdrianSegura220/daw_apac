	<footer class="page-footer color1">
		<div class="container">
      <div class="center">
        	<h3 class="white-text">Patrocinadores</h3>
          <p class="grey-text text-lighten-4">Torneo APAC 2019</p>
      </div>
			<div class="row">
				<div class="col m6 s12 row">
					<div class="col m3 s4">
						<div class="footer_logoContainer hoverable">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m3 s4">
						<div class="footer_logoContainer">
							<i class="large material-icons">assignment_ind</i>
						</div>
					</div>
				</div>
				<div class="col m6 s12 row">
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
					<div class="col m2 s3">
						<div class="footer_logoContainer">
							<i class="medium material-icons">assignment_ind</i>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
            <div class="row">
            	<div class="col l6 m6 s12">
                	<h5 class="white-text center-align">APAC</h5>
                	<p class="grey-text text-lighten-4 center-align">APAC es una institución sin fines de lucro encargada de brindar atención especializada a las personas con parálisis cerebral y otras discapacidades.</p>
                	<p class="grey-text text-lighten-4 center-align">¡Conoce más sobre APAC!</p>
                	<a class="grey-text text-lighten-3" href="#!"><p class="grey-text text-lighten-4 center-align">LOGO</p></a>
              	</div>
              	<div class="col l6 m6 s12">
                	<h5 class="white-text center-align">ByteLogic</h5>
                	<p class="grey-text text-lighten-4 center-align">ByteLogic es el nombre de un equipo 4 estudiantes de ingeniería del Tec de Monterrey especialistas en dar soluciones a nivel desarrollo web.</p>
                	<p class="grey-text text-lighten-4 center-align">¿Quieres saber más sobre nosotros?</p>
                	<a class="grey-text text-lighten-3" href="#!"><p class="grey-text text-lighten-4 center-align">LOGO</p></a>
              	</div>
            </div>
        </div>
		<div class="footer-copyright">
    	<div class="container">
				<a class="grey-text text-lighten-4 right" href="#!">© 2019 ByteLogic</a>
			</div>
		</div>
	</footer>
